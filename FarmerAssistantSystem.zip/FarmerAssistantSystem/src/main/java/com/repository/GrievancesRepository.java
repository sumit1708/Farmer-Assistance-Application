package com.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.GrievancesEntity;

public interface GrievancesRepository extends JpaRepository<GrievancesEntity, Long> {


}
